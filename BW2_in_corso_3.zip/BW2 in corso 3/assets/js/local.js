var emailArray = [];
var passwordArray = [];
var email = [];
var password = [] ;
var elenco = [];
var register = document.getElementById('register');


class Utente {
    constructor(_nomeUtente) {
        this.nomeUtente = _nomeUtente;
    }
    
}

function eventHandler() {
	register.addEventListener('click', function () {
		controlla();
	});
}
 
    document.getElementById('register').addEventListener('click', (e) => {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let passwordRetype = document.getElementById("verifica").value;



    if (email == ""){
        alert("Email richiesta.");
        return ;
    }
    else if (password == ""){
        alert("Password richiesta.");
        return ;
    }
    else if (passwordRetype == ""){
       alert ("Password richiesta.");
        return ;
    }
    else if ( password != passwordRetype ){
        alert("Password non è corretta. Riprovare");
        return;
    }
    else if(emailArray.indexOf(email) == -1){
        emailArray.push(email);
        passwordArray.push(password);

        (email + "BENVENUTI SUL NOSTRO STORE!");

        document.getElementById("email").value="";
        document.getElementById("password").value="";
        document.getElementById("verifica").value="";
    }
    else{
       alert (email + " È già registrata.");
        return ;
    }

    nuovoUtente = new Utente(email);

    localStorage.setItem('email', JSON.stringify(nuovoUtente));
    });

 

    


    document.getElementById('login').addEventListener('click', (e) =>{

    let email = document.getElementById("logMail").value;
    let password = document.getElementById("logPass").value;

    var i = emailArray.indexOf(email);
    

    if(emailArray.indexOf(email) == -1){
        if (email == ""){
            alert("Email required.");
            return ;
        }
        ("Email does not exist.");
        return ;
    }
    else if(passwordArray[i] != password){
        if (password == ""){
           alert ("Password required.");
            return ;
        }
       alert ("Password does not match.");
        return ;
    }
    else {
       alert (email + " yor are login Now \n welcome to our website.");
        location.href = 'index.html';

        document.getElementById("logMail").value ="";
        document.getElementById("logPass").value="";
         controlla();
        return ;

        
    }
    
});

function controlla() {
    if (email.value != '' && password.value != '') {
        var data = {
            email: email.value,
            password: password.value
        };
        addData(data);
        
    } 
}


window.addEventListener('DOMContentLoaded', init);

function init() {
	email = document.getElementById('email');
	password = document.getElementById('password');
	login = document.getElementById('login');
	printData();
    eventHandler();
	
}






async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco/', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
        
	});
	
}


function printData() {
	fetch('http://localhost:3000/elenco/')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			
		});
}
// let persone = [];
// persone = localStorage.getItem('email');
// let persone2 = JSON.parse(persone);
// console.log (persone2.nomeUtente);


var elenco= [];
elenco= JSON.parse(localStorage.getItem('elenco'));
document.getElementById('logout').addEventListener('click', (e) => {
    location.href = 'index.html';
});


