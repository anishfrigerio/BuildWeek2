// Capire su che pagina si è e fare il print dei prodotti di quella categoria

// PRINT SU CATEGORIA MOTO

var listino = [];
// var titoli = [...document.querySelectorAll('.titoliProdotto')];
// var prezzi = [...document.querySelectorAll('.prezziProdotto')];
// var img = [...document.querySelectorAll('.imgProdotto')];

window.addEventListener('DOMContentLoaded', init);
function init() {
  printListino();
}

function printListino() {
  fetch('assets/data/data.json').then((response) => {
    return response.json();
  }).then((data) => {
    listino = data;
    let dynamic = document.querySelector('.productCards');
    for (let i = 0; i < listino[1].moto.length; i++) {
      let fetch = document.querySelector('.productCards').innerHTML;
      dynamic.innerHTML = fetch + `<div class="col-sm-6 col-lg-4 col-xl-3 mb-3">
      <a href="#" onclick="stampaDettaglio(${i})">
        <div class="hoverCards card w-100 bg-dark text-warning" style="width: 18rem;">
        <div class="imgProdotto">
        <img src="${listino[1].moto[i].imgUno}" class="d-block w-100 productImg" alt="...">
        </div>
      </a>
        <div class="card-body">
          <h5 class="titoliProdotto card-title ">${listino[1].moto[i].nome}</h5>
          <p class="card-text prezziProdotto">${listino[1].moto[i].prezzo}</p>
          <button type="button" class="btn btn-warning btn-sm shadow add-to-cart-btn" onClick="spostaInStorage(${i})">Aggiungi al carrello <i class="bi bi-cart-plus-fill"></i></button>
      </div>
    </div>
    </div>`;
    }
  }).catch(error =>{
    alert(`User live server or local server`);
  });
}

// PRINT DATI DAL JSON su pagina DETTAGLI

var elenco = [];
// var titolo = document.getElementById('titoloProdotto');
// var prezzo = document.getElementById('prezzoProdotto');
// var descrizione = document.getElementById('descrizioneProdotto');
// var codice = document.getElementById('codiceProdotto');
// var divisione = document.getElementById('divisioneProdotto');
// var immagine1 = document.getElementById('immagine1');
// var immagine2 = document.getElementById('immagine2');

// ATTENZIONE I VALORI ARRAY DEVONO ESSERE DELLE VARIABILI

function stampaDettaglio(numero) {

  fetch('assets/data/data.json').then((response) => {
    return response.json();
  }).then((data) => {
    elenco = data;
    let dynamic = document.querySelector('.productCards');

      
      dynamic.innerHTML = `<div class="container contenuto">
      <div class="row">
        <div class="col-md-6 d-flex justify-content-center">
          <div id="piccolo">
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
              <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active"
                  aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1"
                  aria-label="Slide 2"></button>
              </div>
              <div class="carousel-inner">
                <div class="carousel-item active" id="immagine1">
                <img src="${elenco[1].moto[numero].imgUno}" class="d-block w-100"
                //       alt="...">
                </div>
                <div class="carousel-item" id="immagine2">
                <img src="${elenco[1].moto[numero].imgDue}" class="d-block w-100"
                //       alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
        </div>
        <div class="col-md-6 pt-md-4 pt-3">
          <h3 id="titoloProdotto" class="fw-normal">${elenco[1].moto[numero].nomeIntero}</h3>
          <h2 id="prezzoProdotto">${elenco[1].moto[numero].prezzo}</h2>
          <hr>
          <div class="d-flex align-content-center ">
            <select class="form-select w-25 me-2" aria-label="Default select example">
              <option selected>1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
            </select>
  
            <button type="button" class="btn btn-warning me-2" onClick="spostaInStorage(${elenco[1].moto[numero].id}-1)">Aggiungi al carrello <i
                class="bi bi-cart-plus-fill"></i></button>
            <button type="button" class="btn btn-success"><i class="bi bi-bag-check-fill"></i></button>
          </div>
          <p class="minibox mt-3 p-2 d-inline-block">
            <i class="bi bi-shop-window"></i> Il prodotto selezionato presenta disponibilità nei nostri negozi.
          </p>
        </div>
      </div>
      <div class="row mb-3 mt-md-5">
        <h3>Descrizione</h3>
        <p id="descrizioneProdotto">${elenco[1].moto[numero].descrizione}</p>
      </div>
      <div class="row mb-3">
        <h3>Specifiche</h3>
        <div class="container">
          <table class="table table-bordered border-warning">
            <tbody>
              <tr>
                <th scope="row">Codice prodotto</th>
                <td id="codiceProdotto">${elenco[1].moto[numero].id * 3 + 1300}</td>
              </tr>
              <tr>
                <th scope="row">Spedizione in 48h</th>
                <td>Si</td>
              <tr>
                <th scope="row">Divisione</th>
                <td id="divisioneProdotto">${elenco[1].moto[numero].nome}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>`
  })
}
// CARRELLO
let prodotti = [];

let j = localStorage.getItem('value');
if (j== null){
  j=0;
}
function spostaInStorage(i){
  let cart = document.querySelectorAll('card');
  localStorage.setItem(`carrello${j}`, JSON.stringify(listino[1].moto[i]));
  prodotti = localStorage.getItem(`carrello${j}`);
  let prodotti2 = JSON.parse(prodotti);
  console.log(prodotti2);
   cart.innerHTML = `<div class = "cart-list">
        <h5>${prodotti2.nome}</h5>
        <p>${prodotti2.imgUno}</p>
        <p>${prodotti2.prezzo}</p>
      </div>`
   j++;
   localStorage.setItem('value', JSON.stringify(j))
   

}